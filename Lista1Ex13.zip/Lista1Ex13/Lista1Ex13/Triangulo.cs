﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex13
{
    internal class Triangulo
    {
        private double n1;
        private double n2;
        private double n3;
        private string clas;

        public void setN1(double n)
        {
            n1 = n;
        }
        public void setN2(double n)
        {
            n2 = n;
        }
        public void setN3(double n)
        {
            n3 = n;
        }

        public double getN1()
        {
            return n1;
        }
        public double getN2()
        {
            return n2;
        }
        public double getN3()
        {
            return n3;
        }
        public string getClassificacao()
        {
            return clas;
        }
        public void calcular()
        {
            n1 = Math.Pow(n1, 2);
            n2 = Math.Pow(n2, 2);
            n3 = Math.Pow(n3, 2);

            if ((n1 + n2) == n3)
            {
                clas = "Formam um Triângulo Retângulo";
            }
            else
            {
                if ((n3 + n2) == n1)
                {
                    clas = "Formam um Triângulo Retângulo";
                }
                else
                {
                    if ((n1 + n3) == n2)
                    {
                        clas = "Formam um Triângulo Retângulo";
                    }
                    else
                    {
                        clas = "Não Formam um Triângulo Retângulo";
                    }
                }
            }
        }
    }
}

    