﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex12
{
    internal class Triangulo
    {
        private double n1;
        private double n2;
        private double n3;
        private string clas;

        public void setN1(double n)
        {
            n1 = n;
        }
        public void setN2(double n)
        {
            n2 = n;
        }
        public void setN3(double n)
        {
            n3 = n;
        }

        public double getN1()
        {
            return n1;
        }
        public double getN2()
        {
            return n2;
        }
        public double getN3()
        {
            return n3;
        }
        public string getClassificacao()
        {
            return clas;
        }
        public void calcular()
        {
            if ((n1 + n2) > n3)
            {
                if ((n2 + n3) > n1)
                {
                    if ((n1 + n3) > n2)
                    {
                        if (n1 == n2)
                        {
                            if (n2 == n3)
                            {
                                clas = "Triângulo Equilatero";
                            }
                            else
                            {
                                clas = "Triângulo Isósceles";
                            }
                        }
                        else
                        {
                            if (n1 == n3)
                            {
                                clas = "Triângulo Isósceles";
                            }
                            else
                            {
                                if (n2 == n3)
                                {
                                    clas = "Triângulo Isósceles";
                                }
                                else
                                {
                                    clas = "Triângulo Escaleno";
                                }
                            }
                        }
                    }
                    else
                    {
                        clas = "Não Formam um Triângulo";
                    }
                }
                else
                {
                    clas = "Não Formam um Triângulo";
                }
            }
            else
            {
                clas = "Não Formam um Triângulo";
            }
        }
    }
}

    

