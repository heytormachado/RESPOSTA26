﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex11
{
    internal class PesoIdeal
    {
        private double p;
        private double alt;
        private double relPesoAltura;
        private string clas;

        public void setP(double n)
        {
            p = n;
        }
        public void setAlt(double n)
        {
            alt = n;
        }
        public double getP()
        {
            return p;
        }
        public double setAlt()
        {
            return alt;
        }
        public string getClassificacao()
        {
            return clas;
        }
        public void calcular()
        {
            relPesoAltura = p / Math.Pow(alt, 2);

            if (relPesoAltura < 20)
            {
                clas = "Abaixo do Peso";
            }
            else
            {
                if (relPesoAltura < 25)
                {
                    clas = "Peso Ideal";
                }
                else
                {
                    clas = "Acima do Peso";
                }
            }
        }
    }
}




