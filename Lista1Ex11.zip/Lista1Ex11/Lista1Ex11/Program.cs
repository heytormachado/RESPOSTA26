﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex11
{
    internal class Program
    {
        static void Main(string[] args)
        {
            PesoIdeal peso1;
            peso1 = new PesoIdeal();

            
            Console.Write("Informe o peso em (Kg): ");
            peso1.setP(int.Parse(Console.ReadLine()));

            Console.Write("Informe a altura em (m): ");
            peso1.setAlt(int.Parse(Console.ReadLine()));

            peso1.calcular();

            

            Console.WriteLine("{0}", peso1.getClassificacao());
        }
    }
}
