﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex7
{
    internal class Dolar
    {
        private double cotDolar;
        private double dol;
        private double reais;

        public void setCotDolar(double n)
        {
            cotDolar = n;
        }
        public void setDolar(double n)
        {
            dol = n;
        }

        public double getCotDolar()
        {
            return cotDolar;
        }
        public double getDolar()
        {
            return dol;
        }

        public double getReais()
        {
            return reais;
        }

        public void operacao()
        {
            reais = cotDolar * dol;
        }
        



    }
}
