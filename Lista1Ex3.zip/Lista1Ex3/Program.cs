﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Quadrado area1;
            area1 = new Quadrado();

            Console.Write("Digite o valor da diagonal do quadrado: ");
            area1.setDiag(int.Parse(Console.ReadLine()));


            area1.calcular();

            Console.WriteLine("A área do quadrado de diagonal {0} é {1}m²",
                area1.getDiag(), area1.getArea());
        }
    }
}
