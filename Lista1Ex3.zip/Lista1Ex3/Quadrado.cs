﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex3
{
    internal class Quadrado
    {
        private double diag;
        private double area;
        private double lado;

        public void setDiag(int n)
        {
            diag = n;
        }

       

        public double getDiag()
        {
            return diag;
        }
        public double getArea()
        {
            return area;
        }



        public void calcular()
        {

            lado = diag / Math.Sqrt(2);
            area = Math.Pow(lado, 2);

        }

    }
}
