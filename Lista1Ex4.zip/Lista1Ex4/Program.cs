﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex4
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Triangulo area1;
            area1 = new Triangulo();

            Console.Write("Digite o valor da base do Triangulo: ");
            area1.setB(int.Parse(Console.ReadLine()));

            Console.Write("Digite o valor da altura do Triangulo: ");
            area1.setH(int.Parse(Console.ReadLine()));

            area1.calcular();

            Console.WriteLine("A área do Triangulo de base {0} e altura {1} é {2}m²",
                area1.getB(), area1.getH(), area1.getArea());
        }
    }
}
