﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex4
{
    internal class Triangulo
    {
        private int b;
        private int h;
        private int area;

        public void setB(int n)
        {
            b = n;
        }
        public void setH(int n)
        {
            h = n;
        }
        public int getB()
        {
            return b;
        }
        public int getH()
        {
            return h;
        }

        public int getArea()
        {
            return area;
        }
        public void calcular()
        {
            area = (b * h)/2;
        }

    }
    }

