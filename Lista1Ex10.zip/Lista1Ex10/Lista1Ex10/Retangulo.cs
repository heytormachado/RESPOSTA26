﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex10
{
    internal class Retangulo
    {
        private double bas;
        private double alt;
        private double area;
        private string areaClas;

        public void setBas(double n)
        {
            bas = n;
        }
        public void setAlt(double n)
        {
            alt = n;
        }
        public double getBas()
        {
            return bas;
        }
        public double getAlt()
        {
            return alt;
        }

        public string getAreaClas()
        {
            return areaClas;
        }
        public void calcular()
        {
            area = bas * alt;

            if (area > 100)
            {
                areaClas = "Terreno Grande";
            }
            else
            {
                areaClas = "Terreno Pequeno";
            }

        }
    }
}
    
