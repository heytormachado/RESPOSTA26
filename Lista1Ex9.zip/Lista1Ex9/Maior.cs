﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex9
{
    internal class Maior
    {
        private double n1;
        private double n2;
        private int maior;

        public void setN1(double v)
        {
            n1 = v;
        }
        public void setN2(double v)
        {
            n2 = v;
        }
        public double getN2()
        {
            return n2;
        }
        public double getN1()
        {
            return n1;
        }
        public void comparar1()
        {
            if (n1 > n2)
            {
                maior = 1;
            }
            else
            if(n1 < n2)
            {
                maior = 2;
            }
            else 
            {
                maior = 0;
            }
        }
       
        public int getM()
        {
            return maior;
        }
    }
}
