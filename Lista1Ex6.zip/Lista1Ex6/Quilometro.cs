﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex6
{
    internal class Quilometro
    {
        private double km;
        private double milmarit;
        

        public void setMilmarit(double n)
        {
            milmarit = n;
        }
        
        public double getMilmarit()
        {
            return milmarit;
        }
       

        public double getKm()
        {
            return km;
        }
        public void calcular()
        {
            km = milmarit * 1.852;
        }
    }
}
