﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex8
{
    internal class Maior
    {
        private double n1;
        private double n2;
        private double maior;

        public void setN1(double n)
        {
            n1 = n;
        }
        public void setN2(double n)
        {
            n2 = n;
        }
        public double getN1()
        {
            return n1;
        }
        public double getN2()
        {
            return n2;
        }
        public void comparar1()
        {
            if (n1 > n2)
            {
                maior = n1;
            }
        }
        public void comparar2()
        {
            if (n2 > n1)
            {
                maior = n2;
            }
        }
        public double getMaior()
        {
            return maior;
        }
    }
}
